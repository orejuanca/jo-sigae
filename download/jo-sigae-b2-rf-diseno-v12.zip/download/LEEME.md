================================================================
JO-SIGAE - ENTREGA v12 - RF: DISENO DEL FORMATO EMG CELDA-A-CELDA
   (mejora de diseño sobre v11 - incluye todo lo de v10 y v11)
================================================================

Que corrige esta entrega
----------------------------------------------------------------
El dibujo del formato RESUMEN FINAL ya es el del Ministerio,
copia directa de tus hojas RF 1°..5° del Excel. Lo que se pidió
y quedó hecho, punto por punto:

1) LAS LINEAS: TODAS, sin excepción. El dibujo completo son
   ~183 trazos finos por hoja (100 horizontales + 83 verticales
   en 1°). Ya no faltan: el marco que encierra toda la hoja,
   la caja del título con sus divisiones internas, las 8 líneas
   del bloque II, las subdivisiones internas de la cabecera
   (Cédula/Apellidos/Nombres/Lugar/EF/SEXO/FECHA y áreas),
   el pie (celda grande "Total de Áreas de Formación" +
   etiquetas + totales), las líneas del bloque V/VI, la caja
   VII con su línea interna y el VIII/IX con las dos cajas de
   sello cerradas.

2) EL LOGO: el encabezado oficial "Gobierno Bolivariano de
   Venezuela | Ministerio del Poder Popular para la Educación"
   (con la bandera) salió DIRECTO de tu Excel (imagen anclada
   en A1 de las 5 hojas RF) y va en su posición exacta.

3) TEXTOS EN VERTICAL: SEXO, DIA, MES y AÑO ahora van
   rotados 90 grados (se leen de abajo hacia arriba), igual
   que el formato oficial, en los 5 grados.

4) DIVISIONES DE PALABRA: tal como el original:
   "Cédula de / Identidad" en dos líneas, "FECHA DE /
   NACIMIENTO" en dos, "SELLO DE LA ZONA / EDUCATIVA" en dos,
   y en los nombres de áreas del bloque V los quiebres del
   original. La cabecera de áreas quedó igual a la oficial:
   ÁREAS DE FORMACIÓN + ÁREA COMÚN, áreas 1 a 7 dobles,
   8 en adelante simples con sus códigos (CA, ILE, MA, EF,
   AP, CN, GHC, OC, PGCRP + GRUPO en 1°/2°; FI, QU, BI, CT,
   GHC, FSN en 3°/4°/5°) y la fila 12 con GRUPO.

5) LA CEDULA: columna reducida como pediste. La celda mide un
   20% menos de ancho y "V12345678900" (el caso más largo)
   queda completo y holgado, no apretado.

6) ORTOGRAFIA CORRECTA PRIMERO (tu regla): las erratas del
   original NO se copian:
   - "GRUPOS DECREACIÓN" -> "GRUPOS DE CREACIÓN" (en 1° y 2°)
   - "Matemática" -> "Matemáticas" (3°, 4° y 5°)
   - "Ciencias de La Tierra" -> "Ciencias de la Tierra"
   - "Apellidos y Nombres" -> "Apellidos y Nombres del Profesor"
   - "FIRMA"/"Firma" -> "Firma:" (uniforme)
   - "Cédula de Identidad.:" -> "Cédula de Identidad:" (sin
     el puntico)
   - espacios de más fuera (antes de los saltos y al final de
     las etiquetas)
   Lo que SI se mantiene: los asteriscos (*) del formato y las
   dos líneas del sello, que son diseño, no errores.

Como lo aplicas (D:\jo-sigae)
----------------------------------------------------------------
1. Copia el contenido de este zip SOBRE D:\jo-sigae
   (reemplaza los archivos que pide).
   En PowerShell:
     Expand-Archive jo-sigae-b2-rf-diseno-v12.zip -DestinationPath D:\temp-v12
     Copy-Item D:\temp-v12\* D:\jo-sigae\ -Recurse -Force
2. NO toques la base de datos: esta entrega no cambia schema ni
   datos. No hace falta correr seed.
3. Detén el servidor si está corriendo (Ctrl+C), y vuélvelo a
   levantar:
     pnpm dev
4. Abre http://localhost:3000 -> RESUMEN FINAL y prueba:
   - 5° D FINAL JULIO - 2022 -> PRIMERA HOJA (35 alumnos,
     logo, verticales, totales) y SEGUNDA HOJA (el alumno 36
     + asteriscos).
   - 1° A FINAL -> los asteriscos en la primera fila en blanco
     y SIN CEDULA (4 alumnos con cedula escolar V+11).
   - IMPRIMIR HOJA con papel OFICIO (8.5 x 13), margen 0.

Que NO cambia
----------------------------------------------------------------
- La data y la mecanica de la v10/v11 están intactas: mismas
  respuestas, mismos alumnos, mismas notas, mismas
  observaciones (pruebas: 54/54 contra los casos reales del
  Excel).
- Los demás módulos no se tocan.

Si algo no cuadra
----------------------------------------------------------------
Anota GRADO + SECCION + TIPO + MES y qué ves en pantalla vs tu
impreso, y lo cuadro en la siguiente.
