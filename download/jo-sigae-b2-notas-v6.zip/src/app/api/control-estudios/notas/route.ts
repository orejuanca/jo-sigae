import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

// ==================== BLOQUE 2: NOTAS ====================
// Reglas de la escuela (no negociables):
// - Regulares: SOLO se guardan los 3 lapsos. La definitiva es calculada (nunca se guarda),
//   igual que el Excel: si un lapso vale "P" el final es P; "NC" no cuenta para el promedio.
// - Cualitativas (OC, PGCRP): letras como en el Excel (A/B/C/D y EX=EXONERADO).
// - GRUPO: columna propia del Excel (valor "EXONERADO"); en MP es un valor único (lapso 4).
// - MP: 4 momentos ÚNICOS E INDEPENDIENTES (1M OCT, 2M DIC, 3M ENE, 4M JUN).
//   Nota >= 10 en cualquier momento = APROBADA (los siguientes se anulan con "*",
//   derivado, nunca guardado). Insuficiente = "IN". Sin definitiva ni promedio.
//   Aplazado en 4M -> queda MP para el próximo año (se aplica en el cierre del año).
// - ORDEN DE LISTADOS: todos los listados van por CÉDULA de menor a mayor (regla del usuario).

const CUALITATIVAS: Record<string, string[]> = {
  OC: ['A', 'B', 'C', 'D', 'EX'],
  PGCRP: ['A', 'B', 'C', 'D', 'EX'],
};

const MESES_MOMENTO = ['1M OCTUBRE', '2M DICIEMBRE', '3M ENERO', '4M JUNIO'];
const VALOR_GRUPO = 'EXONERADO'; // único valor usado en la planilla 2021-2022

function esCualitativa(codigo: string) {
  return codigo in CUALITATIVAS;
}

// cédula -> dígitos (para ordenar numéricamente: "V 32787155" -> 32787155)
function cedNum(cedula: string): number {
  const n = Number((cedula || '').replace(/\D/g, ''));
  return isFinite(n) ? n : Number.MAX_SAFE_INTEGER;
}
function ordenarPorCedula<T>(lista: T[], ced: (x: T) => string): T[] {
  return [...lista].sort((a, b) => cedNum(ced(a)) - cedNum(ced(b)) || ced(a).localeCompare(ced(b)));
}

// Valida una nota de lapso: número 1-20 con 1 decimal, "NC", "P", o letra si cualitativa
function validarNotaLapso(codigo: string, raw: string): { ok: true; valor: string } | { ok: false; error: string } {
  const v = raw.trim().toUpperCase().replace(',', '.');
  if (v === '') return { ok: true, valor: '' };
  if (esCualitativa(codigo)) {
    if (!CUALITATIVAS[codigo].includes(v)) {
      return { ok: false, error: `VALOR_INVALIDO (use ${CUALITATIVAS[codigo].join('/')})` };
    }
    return { ok: true, valor: v };
  }
  if (v === 'NC' || v === 'P') return { ok: true, valor: v }; // no cursante / pendiente (códigos del Excel)
  const n = Number(v);
  if (!isFinite(n) || n < 1 || n > 20) return { ok: false, error: 'NOTA_INVALIDA (1 a 20, NC o P)' };
  if ((v.split('.')[1] || '').length > 1) return { ok: false, error: 'MAX_1_DECIMAL' };
  return { ok: true, valor: String(n) };
}

// Valida una nota de momento MP: "IN" o número >= 10 (aprobación)
function validarNotaMomento(raw: string): { ok: true; valor: string } | { ok: false; error: string } {
  const v = raw.trim().toUpperCase().replace(',', '.');
  if (v === '') return { ok: true, valor: '' };
  if (v === 'IN') return { ok: true, valor: 'IN' };
  const n = Number(v);
  if (!isFinite(n) || n < 10 || n > 20) return { ok: false, error: 'NOTA_MP_INVALIDA (10 a 20, o IN)' };
  if ((v.split('.')[1] || '').length > 1) return { ok: false, error: 'MAX_1_DECIMAL' };
  return { ok: true, valor: String(n) };
}

// GET /api/control-estudios/notas?grado=1           -> secciones de ese grado
// GET /api/control-estudios/notas?grado=1&seccion=A -> planilla completa (regular o MP)
export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const grado = sp.get('grado') || '';
    const codigo = sp.get('seccion') || '';
    const ano = await prisma.anoEscolar.findFirst({ where: { activo: true } });
    if (!ano) return NextResponse.json({ error: 'SIN_ANO_ACTIVO' }, { status: 400 });

    if (!grado) return NextResponse.json({ error: 'FALTA_GRADO' }, { status: 400 });

    // lista de secciones del grado (para el segundo selector)
    if (!codigo) {
      const secciones = await prisma.seccion.findMany({
        where: { anoEscolarId: ano.id, grado },
        orderBy: { codigo: 'asc' },
        select: { id: true, codigo: true, tipo: true },
      });
      return NextResponse.json({ ano: ano.nombre, secciones });
    }

    const seccion = await prisma.seccion.findUnique({
      where: { anoEscolarId_grado_codigo: { anoEscolarId: ano.id, grado, codigo } },
    });
    if (!seccion) return NextResponse.json({ error: 'SECCION_NO_EXISTE' }, { status: 404 });

    const inscripciones = ordenarPorCedula(
      await prisma.inscripcion.findMany({
        where: { seccionId: seccion.id, activo: true },
        include: { alumno: true },
      }),
      i => i.alumno.cedula
    );

    if (seccion.tipo === 'MP') {
      // ===== VISTA MP: una fila por alumno x materia pendiente =====
      const codigosPend = new Set<string>();
      for (const i of inscripciones) {
        if (i.materiaPend1) codigosPend.add(i.materiaPend1);
        if (i.materiaPend2) codigosPend.add(i.materiaPend2);
      }
      const asignaturas = await prisma.asignatura.findMany({
        where: { codigo: { in: [...codigosPend] } },
        orderBy: { orden: 'asc' },
      });
      const asigByCod = new Map(asignaturas.map(a => [a.codigo, a]));
      const filas: {
        inscripcionId: string; alumnoId: string; nombre: string; cedula: string;
        numeroLista: string | null; materiaId: string; materiaCodigo: string; materiaNombre: string;
      }[] = [];
      for (const i of inscripciones) {
        const nombre = `${i.alumno.apellidos}, ${i.alumno.nombres}`;
        for (const cod of [i.materiaPend1, i.materiaPend2]) {
          if (!cod) continue;
          const a = asigByCod.get(cod);
          if (!a) continue; // código de la sábana que no es asignatura del catálogo
          filas.push({
            inscripcionId: i.id, alumnoId: i.alumnoId, nombre,
            cedula: i.alumno.cedula, numeroLista: i.numeroLista,
            materiaId: a.id, materiaCodigo: a.codigo, materiaNombre: a.nombre,
          });
        }
      }
      const momentos = await prisma.notaMomento.findMany({
        where: { inscripcionId: { in: inscripciones.map(i => i.id) } },
      });
      const momentosMap: Record<string, string> = {};
      for (const m of momentos) {
        if (m.valor !== null) momentosMap[`${m.inscripcionId}|${m.asignaturaId}|${m.momento}`] = m.valor;
      }
      // GRUPO único por estudiante (lapso 4 en secciones MP)
      const grupos = await prisma.notaGrupo.findMany({
        where: { inscripcionId: { in: inscripciones.map(i => i.id) }, lapso: 4 },
      });
      const grupoMap: Record<string, string> = {};
      for (const g of grupos) {
        if (g.valor !== null) grupoMap[g.inscripcionId] = g.valor;
      }
      return NextResponse.json({
        tipo: 'MP', ano: ano.nombre,
        seccion: { id: seccion.id, grado: seccion.grado, codigo: seccion.codigo },
        etiquetasMomento: MESES_MOMENTO,
        materias: asignaturas.map(a => ({ id: a.id, codigo: a.codigo, nombre: a.nombre })),
        filas, momentos: momentosMap, grupo: grupoMap,
      });
    }

    // ===== VISTA REGULAR: alumnos x asignaturas de la sección =====
    const docSec = await prisma.docenteSeccion.findMany({
      where: { seccionId: seccion.id },
      include: { asignatura: true },
    });
    const materias = docSec
      .map(d => d.asignatura)
      .sort((a, b) => a.orden - b.orden)
      .map(a => ({ id: a.id, codigo: a.codigo, nombre: a.nombre, cualitativa: esCualitativa(a.codigo) }));

    const notas = await prisma.notaLapso.findMany({
      where: { inscripcionId: { in: inscripciones.map(i => i.id) } },
    });
    const notasMap: Record<string, string> = {};
    for (const n of notas) {
      if (n.valor !== null) notasMap[`${n.inscripcionId}|${n.asignaturaId}|${n.lapso}`] = n.valor;
    }
    // GRUPO por lapso (columna GRUPO del Excel)
    const grupos = await prisma.notaGrupo.findMany({
      where: { inscripcionId: { in: inscripciones.map(i => i.id) }, lapso: { in: [1, 2, 3] } },
    });
    const grupoMap: Record<string, string> = {};
    for (const g of grupos) {
      if (g.valor !== null) grupoMap[`${g.inscripcionId}|${g.lapso}`] = g.valor;
    }
    return NextResponse.json({
      tipo: 'REGULAR', ano: ano.nombre,
      seccion: { id: seccion.id, grado: seccion.grado, codigo: seccion.codigo },
      materias,
      estudiantes: inscripciones.map(i => ({
        inscripcionId: i.id, alumnoId: i.alumnoId,
        nombre: `${i.alumno.apellidos}, ${i.alumno.nombres}`,
        cedula: i.alumno.cedula, numeroLista: i.numeroLista,
      })),
      notas: notasMap, grupo: grupoMap,
    });
  } catch (e) {
    console.error('GET notas:', e);
    return NextResponse.json({ error: 'ERROR_NOTAS_GET', detalle: String(e) }, { status: 500 });
  }
}

// PUT /api/control-estudios/notas
// body: { inscripcionId, asignaturaId?, grupo?, lapso? (1-3, o 4 solo GRUPO en MP) | momento? (1-4), valor: string | null }
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { inscripcionId } = body as { inscripcionId?: string };
    const esGrupo = body.grupo === true;
    const asignaturaId = esGrupo ? null : (body.asignaturaId as string | undefined);
    const lapso = typeof body.lapso === 'number' ? body.lapso : null;
    const momento = typeof body.momento === 'number' ? body.momento : null;
    const rawValor = body.valor === null || body.valor === undefined ? '' : String(body.valor);

    if (!inscripcionId || (!esGrupo && !asignaturaId)) return NextResponse.json({ error: 'FALTAN_IDS' }, { status: 400 });
    if (esGrupo === false && (lapso === null) === (momento === null)) {
      return NextResponse.json({ error: 'INDICAR_LAPSO_O_MOMENTO' }, { status: 400 });
    }

    const inscripcion = await prisma.inscripcion.findUnique({
      where: { id: inscripcionId }, include: { seccion: true },
    });
    if (!inscripcion || !inscripcion.activo) return NextResponse.json({ error: 'INSCRIPCION_NO_VALIDA' }, { status: 404 });

    // ---------- GRUPO (columna del Excel; MP = valor único en lapso 4) ----------
    if (esGrupo) {
      if (lapso === null) return NextResponse.json({ error: 'LAPSO_INVALIDO' }, { status: 400 });
      const esMp = inscripcion.seccion.tipo === 'MP';
      if (esMp ? lapso !== 4 : (lapso < 1 || lapso > 3)) {
        return NextResponse.json({ error: 'LAPSO_INVALIDO' }, { status: 400 });
      }
      const valor = rawValor.trim().toUpperCase();
      if (valor === '') {
        await prisma.notaGrupo.deleteMany({ where: { inscripcionId, lapso } });
        return NextResponse.json({ ok: true, valor: null });
      }
      if (valor !== VALOR_GRUPO) {
        return NextResponse.json({ error: `VALOR_GRUPO_INVALIDO (use ${VALOR_GRUPO})` }, { status: 400 });
      }
      await prisma.notaGrupo.upsert({
        where: { inscripcionId_lapso: { inscripcionId, lapso } },
        update: { valor },
        create: { inscripcionId, lapso, valor },
      });
      return NextResponse.json({ ok: true, valor });
    }

    const asignatura = await prisma.asignatura.findUnique({ where: { id: asignaturaId! } });
    if (!asignatura) return NextResponse.json({ error: 'ASIGNATURA_NO_EXISTE' }, { status: 404 });
    const aid: string = asignaturaId as string;

    // ---------- LAPSO (secciones regulares) ----------
    if (lapso !== null) {
      if (lapso < 1 || lapso > 3) return NextResponse.json({ error: 'LAPSO_INVALIDO' }, { status: 400 });
      if (inscripcion.seccion.tipo === 'MP') {
        return NextResponse.json({ error: 'LOS_MOMENTOS_MP_NO_USAN_LAPSOS' }, { status: 400 });
      }
      const val = validarNotaLapso(asignatura.codigo, rawValor);
      if (!val.ok) return NextResponse.json({ error: val.error }, { status: 400 });
      const clave = { inscripcionId_asignaturaId_lapso: { inscripcionId, asignaturaId: aid, lapso } };
      if (val.valor === '') {
        await prisma.notaLapso.deleteMany({ where: { inscripcionId, asignaturaId: aid, lapso } });
        return NextResponse.json({ ok: true, valor: null });
      }
      await prisma.notaLapso.upsert({
        where: clave,
        update: { valor: val.valor },
        create: { inscripcionId, asignaturaId: aid, lapso, valor: val.valor },
      });
      return NextResponse.json({ ok: true, valor: val.valor });
    }

    // ---------- MOMENTO (secciones MP) ----------
    const m = momento as number;
    if (m < 1 || m > 4) return NextResponse.json({ error: 'MOMENTO_INVALIDO' }, { status: 400 });
    if (inscripcion.seccion.tipo !== 'MP') {
      return NextResponse.json({ error: 'SOLO_SECCIONES_MP' }, { status: 400 });
    }
    const val = validarNotaMomento(rawValor);
    if (!val.ok) return NextResponse.json({ error: val.error }, { status: 400 });

    const previos = await prisma.notaMomento.findMany({
      where: { inscripcionId, asignaturaId: aid, momento: { lt: m } },
      orderBy: { momento: 'asc' },
    });
    const posteriores = await prisma.notaMomento.findMany({
      where: { inscripcionId, asignaturaId: aid, momento: { gt: m } },
    });

    if (val.valor === '') {
      // vaciar: no puede haber momentos posteriores con valor (evita huecos)
      if (posteriores.some(p => p.valor !== null)) {
        return NextResponse.json({ error: 'VACIE_PRIMERO_LOS_MOMENTOS_POSTERIORES' }, { status: 400 });
      }
      await prisma.notaMomento.deleteMany({ where: { inscripcionId, asignaturaId: aid, momento: m } });
      return NextResponse.json({ ok: true, valor: null });
    }

    // secuencia: todos los momentos anteriores deben estar asentados
    if (previos.length < m - 1) {
      return NextResponse.json({ error: 'ASENTE_PRIMERO_LOS_MOMENTOS_ANTERIORES' }, { status: 400 });
    }
    // si ya aprobó en un momento anterior, los siguientes quedan anulados (*)
    const aprobadaEn = previos.find(p => p.valor !== null && p.valor !== 'IN' && Number(p.valor) >= 10);
    if (aprobadaEn) {
      return NextResponse.json({ error: `MATERIA_YA_APROBADA_EN_M${aprobadaEn.momento}` }, { status: 400 });
    }

    await prisma.notaMomento.upsert({
      where: { inscripcionId_asignaturaId_momento: { inscripcionId, asignaturaId: aid, momento: m } },
      update: { valor: val.valor },
      create: { inscripcionId, asignaturaId: aid, momento: m, valor: val.valor },
    });
    return NextResponse.json({ ok: true, valor: val.valor });
  } catch (e) {
    console.error('PUT notas:', e);
    return NextResponse.json({ error: 'ERROR_NOTAS_PUT', detalle: String(e) }, { status: 500 });
  }
}
