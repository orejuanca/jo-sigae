﻿'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import { schoolConfig } from '@/lib/school-config'

const DESTINO_POR_DEFECTO = '/control-estudios'

function destinoGuardado(): string {
  try {
    const d = sessionStorage.getItem('login_redirect')
    if (d && d.startsWith('/') && !d.startsWith('//')) return d
  } catch { /* noop */ }
  return DESTINO_POR_DEFECTO
}

export default function LoginPage() {
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { login, isAuthenticated } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (isAuthenticated) {
      router.push(destinoGuardado())
    }
  }, [isAuthenticated, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    if (login(password)) {
      const destino = destinoGuardado()
      try { sessionStorage.removeItem('login_redirect') } catch { /* noop */ }
      router.push(destino)
    } else {
      setError('Contraseña incorrecta')
      setLoading(false)
    }
  }

  if (isAuthenticated) {
    return (
      <main className="min-h-screen flex items-center justify-center bg-gray-50">
        <p className="text-gray-400" aria-live="polite">Cargando...</p>
      </main>
    )
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 via-white to-green-50 p-4">
      <div className="bg-white rounded-xl shadow-lg border border-emerald-200 py-8 w-full max-w-md">
        <header className="text-center space-y-4 px-6 pb-2">
          <div className="mx-auto w-20 h-20 rounded-full overflow-hidden border-2 border-emerald-200 bg-emerald-100 flex items-center justify-center" aria-hidden="true">
            <svg className="w-10 h-10 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-emerald-800">U.E.N. Creación Cúa</h1>
            <p className="text-sm mt-1 text-gray-500">Sistema de Certificaciones Escolares</p>
          </div>
          <div className="text-xs text-gray-400 space-y-0.5">
            <p>Gobierno Bolivariano de Venezuela</p>
            <p>Ministerio del Poder Popular para la Educacion</p>
            <p>Codigo {schoolConfig.od}</p>
            <p>{schoolConfig.direccion}</p>
            <p>Municipio {schoolConfig.municipio}, {schoolConfig.estado}</p>
          </div>
        </header>

        <div className="px-6">
          <form onSubmit={handleSubmit} className="space-y-4" aria-label="Formulario de inicio de sesion">
            <div className="space-y-2">
              <label htmlFor="login-password" className="text-sm font-medium flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                Contraseña de Acceso
              </label>
              <input
                id="login-password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                aria-describedby={error ? "login-error" : undefined}
                aria-invalid={error ? true : undefined}
                className="w-full h-10 px-3 rounded-lg border border-gray-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-sm"
                placeholder="Ingrese la contraseña del sistema"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoFocus
              />
            </div>

            {error && (
              <p id="login-error" className="text-sm text-red-600 bg-red-50 p-2 rounded-lg" role="alert">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading || !password}
              className="w-full h-10 px-4 py-2 bg-emerald-700 hover:bg-emerald-600 disabled:bg-emerald-300 text-white font-semibold rounded-lg transition text-sm"
              aria-busy={loading}
            >
              {loading ? 'Verificando...' : 'Iniciar Sesión'}
            </button>

            <footer className="text-xs text-center text-gray-400">
              Gobierno Bolivariano de Venezuela — Ministerio del Poder Popular para la Educacion
            </footer>
          </form>
        </div>
      </div>
    </main>
  )
}