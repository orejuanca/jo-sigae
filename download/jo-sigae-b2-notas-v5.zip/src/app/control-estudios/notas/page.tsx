'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

// ==================== BLOQUE 2: VISTA DE NOTAS ====================
// Regulares: pestañas [1er Lapso][2do Lapso][3er Lapso][Definitivas].
//   Solo se editan las notas de lapso; la definitiva es promedio calculado (solo lectura).
// MP: los 4 momentos ÚNICOS E INDEPENDIENTES (1M OCT, 2M DIC, 3M ENE, 4M JUN).
//   Al aprobar (>=10) en cualquier momento, los siguientes se anulan con "*".
//   "IN" = insuficiente. Aplazada en 4M = queda MP para el próximo año.

type Materia = { id: string; codigo: string; nombre: string; cualitativa?: boolean };
type Estudiante = { inscripcionId: string; alumnoId: string; nombre: string; cedula: string; numeroLista: string | null };
type FilaMp = Estudiante & { materiaId: string; materiaCodigo: string; materiaNombre: string };
type SeccionInfo = { id: string; codigo: string; tipo: string };
type PayloadRegular = {
  tipo: 'REGULAR'; ano: string; seccion: { id: string; grado: string; codigo: string };
  materias: Materia[]; estudiantes: Estudiante[]; notas: Record<string, string>;
};
type PayloadMp = {
  tipo: 'MP'; ano: string; seccion: { id: string; grado: string; codigo: string };
  etiquetasMomento: string[]; materias: { id: string; codigo: string; nombre: string }[];
  filas: FilaMp[]; momentos: Record<string, string>;
};
type Datos = PayloadRegular | PayloadMp;

const CUAL_LETRAS: Record<string, string[]> = {
  OC: ['A', 'B', 'C', 'D'],
  PGCRP: ['A', 'B', 'C', 'D', 'EX'],
};

// definitiva con 2 decimales sin ceros de más: 18 | 15.5 | 16.33
function fmtNota(n: number): string {
  const s = (Math.round(n * 100) / 100).toFixed(2);
  return s.replace(/\.00$/, '').replace(/(\.\d)0$/, '$1');
}

export default function NotasPage() {
  const [grado, setGrado] = useState('');
  const [codigo, setCodigo] = useState('');
  const [secciones, setSecciones] = useState<SeccionInfo[]>([]);
  const [datos, setDatos] = useState<Datos | null>(null);
  const [tab, setTab] = useState<number>(1); // 1|2|3 lapsos, 0 = definitivas
  const [valores, setValores] = useState<Record<string, string>>({});
  const [celdaEstado, setCeldaEstado] = useState<Record<string, string>>({}); // 'guardando' | 'ok' | error
  const [mensaje, setMensaje] = useState<string | null>(null);
  const [cargando, setCargando] = useState(false);
  const refs = useRef<Map<string, HTMLInputElement | HTMLSelectElement>>(new Map());
  const timers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  // autoguardado con retardo: guarda 800ms después del último tecleo (o al salir de la celda)
  function programar(clave: string, fn: () => void) {
    const t = timers.current.get(clave);
    if (t) clearTimeout(t);
    timers.current.set(clave, setTimeout(() => { timers.current.delete(clave); fn(); }, 800));
  }
  function cancelar(clave: string) {
    const t = timers.current.get(clave);
    if (t) { clearTimeout(t); timers.current.delete(clave); }
  }
  function cancelarTodos() {
    for (const t of timers.current.values()) clearTimeout(t);
    timers.current.clear();
  }

  // ----- carga de secciones y planilla -----
  useEffect(() => {
    if (!grado) { setSecciones([]); setCodigo(''); return; }
    fetch(`/api/control-estudios/notas?grado=${grado}`)
      .then(r => r.json())
      .then(d => setSecciones(d.secciones || []))
      .catch(() => setSecciones([]));
    setCodigo('');
    setDatos(null);
  }, [grado]);

  const cargarPlanilla = useCallback(async (g: string, c: string) => {
    if (!g || !c) { setDatos(null); return; }
    setCargando(true);
    setMensaje(null);
    cancelarTodos();
    try {
      const r = await fetch(`/api/control-estudios/notas?grado=${g}&seccion=${encodeURIComponent(c)}`);
      const d = await r.json();
      if (!r.ok) { setMensaje(d.error || 'ERROR_CARGA'); setDatos(null); return; }
      setDatos(d);
      setTab(1);
      setValores(d.tipo === 'MP' ? { ...d.momentos } : { ...d.notas });
      setCeldaEstado({});
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => { cargarPlanilla(grado, codigo); }, [grado, codigo, cargarPlanilla]);

  // ----- guardado -----
  async function guardar(clave: string, body: Record<string, unknown>) {
    setCeldaEstado(e => ({ ...e, [clave]: 'guardando' }));
    try {
      const r = await fetch('/api/control-estudios/notas', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = await r.json();
      if (!r.ok) {
        setCeldaEstado(e => ({ ...e, [clave]: d.error || 'ERROR_GUARDAR' }));
        setMensaje(d.error || 'ERROR_GUARDAR');
        return false;
      }
      setCeldaEstado(e => {
        const n = { ...e };
        delete n[clave];
        return n;
      });
      setMensaje(null);
      return true;
    } catch {
      setCeldaEstado(e => ({ ...e, [clave]: 'SIN_CONEXION' }));
      return false;
    }
  }

  function marcarOk(clave: string) {
    setCeldaEstado(e => ({ ...e, [clave]: 'ok' }));
    setTimeout(() => setCeldaEstado(e => {
      if (e[clave] === 'ok') { const n = { ...e }; delete n[clave]; return n; }
      return e;
    }), 1500);
  }

  async function guardarLapso(est: Estudiante, mat: Materia, lapso: number, valor: string) {
    const clave = `L|${est.inscripcionId}|${mat.id}|${lapso}`;
    const vacio = valor.trim() === '';
    const ok = await guardar(clave, {
      inscripcionId: est.inscripcionId, asignaturaId: mat.id, lapso,
      valor: vacio ? null : valor,
    });
    if (ok) {
      setValores(v => {
        const n = { ...v };
        if (vacio) delete n[clave]; else n[clave] = valor.trim().toUpperCase().replace(',', '.');
        return n;
      });
      marcarOk(clave);
    }
  }

  async function guardarMomento(fila: FilaMp, momento: number, valor: string) {
    const clave = `M|${fila.inscripcionId}|${fila.materiaId}|${momento}`;
    const vacio = valor.trim() === '';
    const ok = await guardar(clave, {
      inscripcionId: fila.inscripcionId, asignaturaId: fila.materiaId, momento,
      valor: vacio ? null : valor,
    });
    if (ok) {
      setValores(v => {
        const n = { ...v };
        if (vacio) delete n[clave]; else n[clave] = valor.trim().toUpperCase().replace(',', '.');
        return n;
      });
      marcarOk(clave);
    }
  }

  // ----- derivados -----
  function nota(est: Estudiante, mat: Materia, lapso: number): string {
    return valores[`L|${est.inscripcionId}|${mat.id}|${lapso}`] || '';
  }

  function definitiva(est: Estudiante, mat: Materia): string {
    const v1 = nota(est, mat, 1), v2 = nota(est, mat, 2), v3 = nota(est, mat, 3);
    if (mat.cualitativa) {
      if (!v1 || !v2 || !v3) return '';
      return v1 === v2 && v2 === v3 ? v3 : '?';
    }
    if (!v1 || !v2 || !v3) return '';
    const n1 = Number(v1), n2 = Number(v2), n3 = Number(v3);
    if ([n1, n2, n3].some(n => !isFinite(n))) return '';
    return fmtNota((n1 + n2 + n3) / 3);
  }

  function faltan(mat: Materia, lapso: number): number {
    if (!datos || datos.tipo !== 'REGULAR') return 0;
    return datos.estudiantes.filter(e => !nota(e, mat, lapso)).length;
  }

  // estado de una fila MP (derivado, nunca guardado)
  function estadoMp(fila: FilaMp): { texto: string; clase: string } {
    const vals = [1, 2, 3, 4].map(m => valores[`M|${fila.inscripcionId}|${fila.materiaId}|${m}`] || '');
    const aprob = vals.findIndex(v => v !== '' && v !== 'IN' && Number(v) >= 10);
    if (aprob >= 0) return { texto: `APROBADA ${aprob + 1}M · ${vals[aprob]}`, clase: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
    if (vals[3]) return { texto: 'APLAZADA → QUEDA MP', clase: 'bg-red-100 text-red-800 border-red-300' };
    if (vals.some(v => v)) return { texto: 'EN PROCESO', clase: 'bg-amber-100 text-amber-800 border-amber-300' };
    return { texto: 'SIN ASENTAR', clase: 'bg-gray-100 text-gray-500 border-gray-300' };
  }

  // * derivado: la materia ya se aprobó en un momento anterior
  function anuladoMp(fila: FilaMp, momento: number): boolean {
    for (let m = 1; m < momento; m++) {
      const v = valores[`M|${fila.inscripcionId}|${fila.materiaId}|${m}`] || '';
      if (v !== '' && v !== 'IN' && Number(v) >= 10) return true;
    }
    return false;
  }

  // el momento es editable si es el primero sin asentar (o corrección de uno ya asentado)
  function editableMp(fila: FilaMp, momento: number): boolean {
    if (anuladoMp(fila, momento)) return false;
    for (let m = 1; m < momento; m++) {
      if (!valores[`M|${fila.inscripcionId}|${fila.materiaId}|${m}`]) {
        // hay un hueco antes: solo editable si este momento ya tiene valor
        return !!valores[`M|${fila.inscripcionId}|${fila.materiaId}|${momento}`];
      }
    }
    return true;
  }

  // ----- navegación con teclado (estilo planilla) -----
  function registrar(i: number, j: number) {
    return (el: HTMLInputElement | HTMLSelectElement | null) => {
      if (el) refs.current.set(`${i}-${j}`, el); else refs.current.delete(`${i}-${j}`);
    };
  }

  function teclaCelda(e: React.KeyboardEvent, i: number, j: number, di = 0, dj = 0) {
    const inp = e.currentTarget as HTMLInputElement;
    let destino: { di: number; dj: number } | null = null;
    if (e.key === 'Enter' || e.key === 'ArrowDown') destino = { di: 1, dj: 0 };
    else if (e.key === 'ArrowUp') destino = { di: -1, dj: 0 };
    else if (e.key === 'ArrowRight' && inp.selectionStart === inp.value.length && inp.selectionEnd === inp.value.length) destino = { di, dj: 1 };
    else if (e.key === 'ArrowLeft' && inp.selectionStart === 0 && inp.selectionEnd === 0) destino = { di, dj: -1 };
    if (!destino) return;
    e.preventDefault();
    // blur SIEMPRE antes de mover: dispara el autoguardado aunque la celda
    // de destino no exista o no sea editable (sin notas fantasma en pantalla)
    inp.blur();
    const el = refs.current.get(`${i + destino.di}-${j + destino.dj}`);
    if (el) { el.focus(); (el as HTMLInputElement).select?.(); }
  }

  const claseCelda = (clave: string) => {
    const st = celdaEstado[clave];
    if (st === 'guardando') return 'border-b-2 border-amber-400 bg-amber-50';
    if (st === 'ok') return 'border-b-2 border-emerald-400';
    if (st) return 'border-2 border-red-400 bg-red-50';
    return '';
  };

  const regs = useMemo(() => (datos && datos.tipo === 'REGULAR' ? datos : null), [datos]);
  const mp = useMemo(() => (datos && datos.tipo === 'MP' ? datos : null), [datos]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">NOTAS</h1>
        <p className="text-sm text-gray-500 mt-1">
          Regulares: solo se editan las notas de lapso — la definitiva es el promedio de los tres, calculada por el sistema.
          MP: los 4 momentos (1M octubre, 2M diciembre, 3M enero, 4M junio) — al aprobar, los siguientes se anulan con *.
        </p>
      </div>

      {/* ----- selectores ----- */}
      <div className="flex flex-wrap items-center gap-3 bg-white border border-gray-200 rounded-xl p-4">
        <label className="text-sm font-semibold text-gray-700">GRADO</label>
        <select value={grado} onChange={e => setGrado(e.target.value)}
          className="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
          <option value="">-- elija --</option>
          {['1', '2', '3', '4', '5'].map(g => <option key={g} value={g}>{g}°</option>)}
        </select>
        <label className="text-sm font-semibold text-gray-700">SECCIÓN</label>
        <select value={codigo} onChange={e => setCodigo(e.target.value)} disabled={!grado}
          className="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white disabled:bg-gray-100">
          <option value="">-- elija --</option>
          {secciones.map(s => (
            <option key={s.id} value={s.codigo}>
              {grado}° {s.codigo === 'MP' ? 'MP (materias pendientes)' : s.codigo}
            </option>
          ))}
        </select>
        {datos && (
          <span className="ml-auto flex items-center gap-2 text-sm">
            <span className={`px-2 py-1 rounded font-semibold text-xs ${datos.tipo === 'MP' ? 'bg-purple-100 text-purple-800' : 'bg-sky-100 text-sky-800'}`}>
              {datos.tipo === 'MP' ? 'MATERIAS PENDIENTES' : 'SECCIÓN REGULAR'}
            </span>
            <span className="text-gray-500">AÑO {datos.ano}</span>
            <span className="text-gray-400">·</span>
            <span className="text-gray-600">
              {datos.tipo === 'MP'
                ? `${mp ? new Set(mp.filas.map(f => f.inscripcionId)).size : 0} estudiantes · ${mp?.filas.length || 0} pendientes`
                : `${regs?.estudiantes.length} estudiantes · ${regs?.materias.length} materias`}
            </span>
          </span>
        )}
      </div>

      {mensaje && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-2">
          {mensaje.replace(/_/g, ' ')}
        </div>
      )}

      {cargando && <div className="text-sm text-gray-500">Cargando planilla…</div>}

      {/* ==================== REGULAR ==================== */}
      {regs && (regs.estudiantes.length === 0 ? (
        <div className="bg-white border rounded-xl p-8 text-center text-gray-500">Sin estudiantes inscritos en esta sección.</div>
      ) : (
        <div className="space-y-3">
          <div className="flex gap-1 flex-wrap">
            {[1, 2, 3, 0].map(t => (
              <button key={t} onClick={() => setTab(t)}
                className={`px-4 py-2 text-sm font-semibold rounded-t-lg border transition-colors ${
                  tab === t ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-600 border-gray-300 hover:bg-gray-50'
                }`}>
                {t === 0 ? 'DEFINITIVAS (solo lectura)' : t === 1 ? '1ER LAPSO' : t === 2 ? '2DO LAPSO' : '3ER LAPSO'}
              </button>
            ))}
          </div>

          <div className="bg-white border border-gray-200 rounded-xl overflow-auto max-h-[70vh]">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-slate-100">
                  <th className="sticky left-0 top-0 z-30 bg-slate-100 border-b border-r border-gray-300 px-3 py-2 text-left min-w-[260px]">
                    N° · ESTUDIANTE
                  </th>
                  {regs.materias.map(m => (
                    <th key={m.id} className="sticky top-0 z-20 bg-slate-100 border-b border-gray-300 px-2 py-2 min-w-[72px]">
                      <div className="font-bold">{m.codigo}</div>
                      <div className="font-normal text-[10px] text-gray-500 max-w-[90px] truncate" title={m.nombre}>{m.nombre}</div>
                      {tab !== 0 && (() => {
                        const f = faltan(m, tab);
                        return <div className={`text-[10px] font-semibold ${f === 0 ? 'text-emerald-600' : 'text-gray-400'}`}>{f === 0 ? 'completo' : `faltan ${f}`}</div>;
                      })()}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {regs.estudiantes.map((est, i) => (
                  <tr key={est.inscripcionId} className="hover:bg-gray-50">
                    <td className="sticky left-0 z-10 bg-white border-b border-r border-gray-200 px-3 py-1.5 whitespace-nowrap">
                      <span className="text-gray-400 mr-1">{i + 1}.</span>
                      <span className="font-medium">{est.nombre}</span>
                    </td>
                    {regs.materias.map((m, j) => {
                      const clave = `L|${est.inscripcionId}|${m.id}|${tab}`;
                      if (tab === 0) {
                        return (
                          <td key={m.id} className="border-b border-gray-200 px-2 py-1.5 text-center">
                            <span className="font-semibold text-slate-700">{definitiva(est, m) || <span className="text-gray-300">—</span>}</span>
                          </td>
                        );
                      }
                      if (m.cualitativa) {
                        const letras = CUAL_LETRAS[m.codigo] || ['A', 'B', 'C', 'D'];
                        return (
                          <td key={m.id} className={`border-b border-gray-200 px-1 py-1 text-center ${claseCelda(clave)}`}>
                            <select ref={registrar(i, j)} value={nota(est, m, tab)}
                              onChange={e => guardarLapso(est, m, tab, e.target.value)}
                              className="w-14 text-center bg-transparent outline-none">
                              <option value=""></option>
                              {letras.map(l => <option key={l} value={l}>{l}</option>)}
                            </select>
                          </td>
                        );
                      }
                      return (
                        <td key={m.id} className={`border-b border-gray-200 px-1 py-1 text-center ${claseCelda(clave)}`}>
                          <input ref={registrar(i, j)} type="text" inputMode="decimal"
                            value={nota(est, m, tab)}
                            onChange={e => {
                              const v = e.target.value;
                              setValores(vv => ({ ...vv, [`L|${est.inscripcionId}|${m.id}|${tab}`]: v }));
                              programar(`L|${est.inscripcionId}|${m.id}|${tab}`, () => guardarLapso(est, m, tab, v));
                            }}
                            onBlur={e => {
                              cancelar(`L|${est.inscripcionId}|${m.id}|${tab}`);
                              guardarLapso(est, m, tab, e.target.value);
                            }}
                            onKeyDown={e => teclaCelda(e, i, j, 0, 1)}
                            className="w-14 text-center outline-none focus:bg-sky-50 focus:ring-1 focus:ring-sky-400 rounded"
                            title={`${est.nombre} · ${m.nombre} · ${tab}er/2do/3er lapso`} />
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-gray-500">
            Enter ↓ baja al próximo estudiante · Tab pasa a la siguiente materia · ← → se mueven entre materias · celda vacía = pendiente · se guarda al salir de la celda
            {tab === 0 && ' · Definitiva = promedio exacto de los 3 lapsos (como el Excel); en materias con letras se muestra cuando las tres coinciden'}
          </p>
        </div>
      ))}

      {/* ==================== MP ==================== */}
      {mp && (mp.filas.length === 0 ? (
        <div className="bg-white border rounded-xl p-8 text-center text-gray-500">Sin materias pendientes inscritas en esta sección MP.</div>
      ) : (
        <div className="space-y-3">
          <div className="bg-purple-50 border border-purple-200 text-purple-800 text-xs rounded-lg px-4 py-2">
            Los 4 momentos son INDEPENDIENTES: se evalúa momento a momento hasta que apruebe.
            Al aprobar (nota ≥ 10) en cualquier momento, la materia queda APROBADA y los momentos siguientes se anulan con *.
            Si queda aplazada en 4M (junio), le queda la MP para el próximo año escolar.
          </div>
          <div className="bg-white border border-gray-200 rounded-xl overflow-auto max-h-[70vh]">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-purple-50">
                  <th className="sticky top-0 z-20 bg-purple-50 border-b border-gray-300 px-3 py-2 text-left min-w-[260px]">ESTUDIANTE</th>
                  <th className="sticky top-0 z-20 bg-purple-50 border-b border-gray-300 px-3 py-2 text-left">MATERIA QUE DEBE</th>
                  {mp.etiquetasMomento.map(et => (
                    <th key={et} className="sticky top-0 z-20 bg-purple-50 border-b border-gray-300 px-2 py-2 min-w-[90px]">{et}</th>
                  ))}
                  <th className="sticky top-0 z-20 bg-purple-50 border-b border-gray-300 px-3 py-2">ESTADO</th>
                </tr>
              </thead>
              <tbody>
                {mp.filas.map((fila, i) => {
                  const primera = i === 0 || mp.filas[i - 1].inscripcionId !== fila.inscripcionId;
                  const est = estadoMp(fila);
                  return (
                    <tr key={`${fila.inscripcionId}-${fila.materiaId}`} className={primera ? 'border-t-2 border-gray-300' : ''}>
                      <td className="border-b border-gray-200 px-3 py-1.5 whitespace-nowrap">
                        {primera ? <span className="font-medium">{fila.nombre}</span> : <span className="text-gray-300 text-xs">↳ mismo estudiante</span>}
                      </td>
                      <td className="border-b border-gray-200 px-3 py-1.5">
                        <span className="font-bold">{fila.materiaCodigo}</span>
                        <span className="text-xs text-gray-500 ml-1" title={fila.materiaNombre}>{fila.materiaNombre}</span>
                      </td>
                      {[1, 2, 3, 4].map((m, j) => {
                        const clave = `M|${fila.inscripcionId}|${fila.materiaId}|${m}`;
                        const anulada = anuladoMp(fila, m);
                        if (anulada) {
                          return <td key={m} className="border-b border-gray-200 px-2 py-1 text-center text-gray-400 font-bold" title={`Anulado: aprobó en un momento anterior`}>*</td>;
                        }
                        if (!editableMp(fila, m)) {
                          return <td key={m} className="border-b border-gray-200 px-2 py-1 text-center text-gray-200">·</td>;
                        }
                        return (
                          <td key={m} className={`border-b border-gray-200 px-1 py-1 text-center ${claseCelda(clave)}`}>
                            <input ref={registrar(i, j)} type="text" inputMode="text"
                              value={valores[clave] || ''}
                              onChange={e => {
                                const v = e.target.value.toUpperCase();
                                setValores(vv => ({ ...vv, [clave]: v }));
                                programar(clave, () => guardarMomento(fila, m, v));
                              }}
                              onBlur={e => {
                                cancelar(clave);
                                guardarMomento(fila, m, e.target.value);
                              }}
                              onKeyDown={e => teclaCelda(e, i, j, 0, 1)}
                              className="w-16 text-center outline-none focus:bg-sky-50 focus:ring-1 focus:ring-sky-400 rounded"
                              title={`${fila.nombre} · ${fila.materiaNombre} · momento ${m} (nota ≥ 10 o IN)`} />
                          </td>
                        );
                      })}
                      <td className="border-b border-gray-200 px-3 py-1.5 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded border text-[11px] font-bold whitespace-nowrap ${est.clase}`}>{est.texto}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-gray-500">
            Se escribe el momento en curso (los anteriores deben estar asentados) · nota ≥ 10 aprueba · "IN" = insuficiente · * = anulado por aprobación previa · se guarda al salir de la celda
          </p>
        </div>
      ))}

      {!datos && !cargando && grado && codigo === '' && (
        <div className="bg-white border rounded-xl p-8 text-center text-gray-500">Elija una sección para ver la planilla.</div>
      )}
      {!datos && !cargando && !grado && (
        <div className="bg-white border rounded-xl p-8 text-center text-gray-500">
          Elija el grado y la sección. Las planillas arrancan vacías: aquí se asientan las notas de cada lapso (regulares) y de cada momento (materias pendientes).
        </div>
      )}
    </div>
  );
}
