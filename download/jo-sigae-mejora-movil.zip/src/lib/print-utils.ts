// ─────────────────────────────────────────────────────────────────────────────
// print-utils
// Configuración de impresión compartida (papel + márgenes) para las vistas
// que generan HTML de impresión en un iframe (cert-view, certificaciones-visual).
//
// Comportamiento por defecto = histórico de la app: Legal, sin márgenes.
// Las preferencias se guardan en localStorage para no re-seleccionar cada vez.
// ─────────────────────────────────────────────────────────────────────────────

export const PRINT_PAPERS = {
  legal:  { label: 'Legal (8.5×14")',  cssSize: 'legal',      iframeWidth: '215.9mm' },
  oficio: { label: 'Oficio (8.5×13")', cssSize: '8.5in 13in', iframeWidth: '215.9mm' },
  carta:  { label: 'Carta (8.5×11")',  cssSize: 'letter',     iframeWidth: '215.9mm' },
  a4:     { label: 'A4',               cssSize: 'A4',         iframeWidth: '210mm' },
} as const

export type PrintPaperKey = keyof typeof PRINT_PAPERS

export const PRINT_MARGINS = {
  none:     { label: 'Sin márgenes',  css: '0' },
  estrecho: { label: 'Estrecho 6mm',  css: '6mm' },
  normal:   { label: 'Normal 12.7mm', css: '12.7mm' },
  ancho:    { label: 'Ancho 25.4mm',  css: '1in' },
} as const

export type PrintMarginKey = keyof typeof PRINT_MARGINS

export interface PrintPrefs {
  paper: PrintPaperKey
  margin: PrintMarginKey
}

const PRINT_PREFS_KEY = 'jo-sigae-print-prefs'

/** Preferencias por defecto = comportamiento histórico (Legal, sin márgenes). */
export const DEFAULT_PRINT_PREFS: PrintPrefs = { paper: 'legal', margin: 'none' }

export function loadPrintPrefs(): PrintPrefs {
  if (typeof window === 'undefined') return DEFAULT_PRINT_PREFS
  try {
    const raw = window.localStorage.getItem(PRINT_PREFS_KEY)
    if (raw) {
      const p = JSON.parse(raw) as Partial<PrintPrefs>
      if (p?.paper && p.paper in PRINT_PAPERS && p?.margin && p.margin in PRINT_MARGINS) {
        return { paper: p.paper as PrintPaperKey, margin: p.margin as PrintMarginKey }
      }
    }
  } catch {
    // localStorage bloqueado o JSON corrupto: usar defaults
  }
  return DEFAULT_PRINT_PREFS
}

export function savePrintPrefs(prefs: PrintPrefs): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(PRINT_PREFS_KEY, JSON.stringify(prefs))
  } catch {
    // silencioso: si no se puede guardar, simplemente no se persiste
  }
}

/** Regla @page con el papel y márgenes elegidos. */
export function buildPrintPageCss(paper: PrintPaperKey, margin: PrintMarginKey): string {
  const p = PRINT_PAPERS[paper]
  const m = PRINT_MARGINS[margin]
  return `@page{size:${p.cssSize};margin:${m.css}}`
}
