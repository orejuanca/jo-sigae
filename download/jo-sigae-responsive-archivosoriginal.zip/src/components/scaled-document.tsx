'use client'

// ─────────────────────────────────────────────────────────────────────────────
// ScaledDocument
// Escala proporcionalmente documentos de ancho fijo (ej. certificados de 816px)
// cuando la pantalla del dispositivo es más angosta que el documento.
//
// Comportamiento:
//  - Escritorio (ancho disponible >= designWidth): renderiza SIN transform,
//    exactamente igual que antes (no-op visual).
//  - Móvil/tablet (ancho disponible < designWidth): aplica transform:scale()
//    tipo "visor PDF" — el documento conserva su maquetación completa y se ve
//    completo, más pequeño, sin cortes ni aplastamiento.
//  - En impresión (@media print) se anula la escala para no alterar la salida.
// ─────────────────────────────────────────────────────────────────────────────

import { useCallback, useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react'

export const CERT_DOC_WIDTH = 816

interface ScaledDocumentProps {
  children: ReactNode
  /** Ancho de maquetación original del documento (px). Default: 816 */
  designWidth?: number
  className?: string
  style?: CSSProperties
}

export function ScaledDocument({ children, designWidth = CERT_DOC_WIDTH, className, style }: ScaledDocumentProps) {
  const outerRef = useRef<HTMLDivElement>(null)
  const innerRef = useRef<HTMLDivElement>(null)
  const [scale, setScale] = useState(1)
  const [docHeight, setDocHeight] = useState<number | null>(null)

  // Medir ancho disponible y calcular escala
  const measureWidth = useCallback(() => {
    const outer = outerRef.current
    if (!outer) return
    const avail = outer.clientWidth
    if (avail <= 0) return
    setScale(avail < designWidth ? avail / designWidth : 1)
  }, [designWidth])

  // Medir altura natural del documento (sin escalar) para reservar el alto correcto.
  // Se mide el PRIMER HIJO (el documento real) y NO el wrapper interno, porque el
  // wrapper recibe una altura fija al escalar (medirlo a sí mismo anularía el ciclo).
  const measureHeight = useCallback(() => {
    const inner = innerRef.current
    if (!inner) return
    const docEl = inner.firstElementChild as HTMLElement | null
    if (docEl) setDocHeight(docEl.offsetHeight)
  }, [])

  useLayoutEffect(() => {
    measureWidth()
    const ro = new ResizeObserver(measureWidth)
    if (outerRef.current) ro.observe(outerRef.current)
    window.addEventListener('orientationchange', measureWidth)
    return () => {
      ro.disconnect()
      window.removeEventListener('orientationchange', measureWidth)
    }
  }, [measureWidth])

  // Observar el documento interno: su altura cambia de forma asíncrona
  // (carga condicional del layout + datos traídos por fetch).
  useLayoutEffect(() => {
    const inner = innerRef.current
    if (!inner) return

    let ro: ResizeObserver | null = null
    const attach = () => {
      const docEl = inner.firstElementChild as HTMLElement | null
      if (!docEl) return
      setDocHeight(docEl.offsetHeight)
      ro?.disconnect()
      ro = new ResizeObserver(() => setDocHeight(docEl.offsetHeight))
      ro.observe(docEl)
    }

    attach()
    // Re-adjuntar cuando el hijo cambia (render condicional del documento)
    const mo = new MutationObserver(attach)
    mo.observe(inner, { childList: true })

    return () => {
      ro?.disconnect()
      mo.disconnect()
    }
  }, [])

  // Re-medir cuando terminan de cargar fuentes/imágenes del documento
  useEffect(() => {
    const t = setTimeout(measureHeight, 500)
    return () => clearTimeout(t)
  }, [measureHeight])

  const scaled = scale < 1

  return (
    <div
      ref={outerRef}
      className={className}
      style={{ width: '100%', overflow: 'hidden', ...style }}
      data-scaled-doc=""
    >
      <div
        ref={innerRef}
        data-scaled-doc-inner=""
        style={{
          width: designWidth,
          margin: '0 auto',
          transform: scaled ? `scale(${scale})` : undefined,
          transformOrigin: 'top left',
          height: scaled && docHeight ? Math.round(docHeight * scale) : undefined,
          overflow: scaled ? 'hidden' : undefined,
        }}
      >
        {children}
      </div>
    </div>
  )
}
