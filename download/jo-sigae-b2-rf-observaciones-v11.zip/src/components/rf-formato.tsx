'use client';

// ==================== RÉPLICA DEL FORMATO EMG ====================
// "Resumen Final del Rendimiento Estudiantil" — Código del Formato: EMG.
// Réplica exacta del formato oficial del Ministerio de Educación tal como lo imprime
// el Excel del plantel: papel OFICIO (8.5 x 13 in), vertical, Arial, escala por grado
// (74/74/71/70/67 % igual que las hojas RF), 35 alumnos por hoja numerados 01..35,
// primera fila en blanco tras el último alumno cerrada con asteriscos, pie de totales
// por área con las fórmulas oficiales y separación de alumnos SIN CEDULA en planillas aparte.

import { GEOMETRIA, MAX_ALUMNOS_HOJA, pad2 } from '@/lib/rf-formato';
import type { CSSProperties } from 'react';

export type ValorRF = number | string;
export type FilaRF = {
  cedula: string; apellidos: string; nombres: string; lugar: string;
  ef: string; sexo: string; dia: string; mesNac: string; anio: string;
  notas: Record<string, ValorRF>; grupo: string;
};
export type AreaRF = { codigo: string; nombre: string; letras: boolean; etiquetaV?: string };
export type DatosRF = {
  ano: string; grado: string; sec: string; secDisplay: string; tipo: string; mes: string;
  areas: AreaRF[];
  institucion: { codigo: string; denominacion: string; direccion: string; telefono: string; municipio: string; entidadFederal: string; director: string; cedulaDirector: string };
  curso: { planEstudio: string; codigo: string; anioCursado: string; seccion: string };
  observaciones: { linea1: string; linea2: string };
  conCedula: FilaRF[]; sinCedula: FilaRF[];
  profesores: { area: string; nombre: string | null; cedula: string | null }[];
  nPorSeccion: number;
};

const B = '1px solid #000';
const f8: CSSProperties = { fontSize: '10.7px', lineHeight: 1.15 };   // Arial 8
const f9: CSSProperties = { fontSize: '12px', lineHeight: 1.1 };      // Arial 9
const f9b: CSSProperties = { fontSize: '12px', fontWeight: 700, lineHeight: 1.1 };
const f10: CSSProperties = { fontSize: '13.3px', lineHeight: 1.05 };  // Arial 10

// la celda de nota se muestra igual que el Excel (formato "00"): entero con 2 dígitos
function mostrarNota(v: ValorRF): string {
  if (v === '' || v === null || v === undefined) return '';
  if (typeof v === 'number') return pad2(Math.round(v));
  return String(v);
}
function esNumerico(v: ValorRF): boolean {
  if (typeof v === 'number') return true;
  return v !== '' && isFinite(Number(v));
}

// ---- pie de totales por área: fórmulas oficiales del formato ----
function statsDeArea(filas: (FilaRF | null)[], codigo: string, letras: boolean) {
  const vs = filas.map(f => (f ? f.notas[codigo] : '') ?? '').filter(v => v !== '');
  if (letras) {
    // áreas con letras (OC, PGCRP): Aprobados = A+B+C+D; No Aprobados = P; Inscritos = A+B+C+D+P
    const es = (v: ValorRF, l: string[]) => l.includes(String(v));
    return {
      inscritos: vs.filter(v => es(v, ['A', 'B', 'C', 'D', 'P'])).length,
      inasistentes: vs.filter(v => v === 'IN').length,
      aprobados: vs.filter(v => es(v, ['A', 'B', 'C', 'D'])).length,
      noAprobados: vs.filter(v => v === 'P').length,
      noCursantes: vs.filter(v => v === 'NC').length,
    };
  }
  const num = vs.filter(esNumerico).map(Number);
  return {
    inscritos: num.length + vs.filter(v => v === 'IN' || v === 'P').length,
    inasistentes: vs.filter(v => v === 'IN').length,
    aprobados: num.filter(n => n >= 9.5).length,
    noAprobados: num.filter(n => n <= 9.49).length + vs.filter(v => v === 'P').length,
    noCursantes: vs.filter(v => v === 'NC').length,
  };
}

export default function RFFormato({ datos, filas }: { datos: DatosRF; filas: FilaRF[] }) {
  const g = GEOMETRIA[datos.grado];
  const areas = datos.areas;
  const W = [...g.id, ...g.areas, g.grupo].reduce((a, b) => a + b, 0);
  const K = g.escala / 100;

  // ---- las 35 ranuras de la hoja: alumno / asteriscos / vacía ----
  const n = Math.min(filas.length, MAX_ALUMNOS_HOJA);
  const slots = Array.from({ length: MAX_ALUMNOS_HOJA }, (_, i) => ({
    numero: pad2(i + 1),
    fila: i < n ? filas[i] : null,
    asteriscos: i === n && n < MAX_ALUMNOS_HOJA,
  }));

  const stats = areas.map(ar => statsDeArea(slots.map(s => s.fila), ar.codigo, ar.letras));
  const nProf = areas.length;
  const hV = 2 * 18 + nProf * 20;

  // anchos de la tabla V (Profesores) y del bloque VI (Identificación del Curso)
  const wV = g.id.reduce((a, b) => a + b, 0) + g.areas.slice(0, 5).reduce((a, b) => a + b, 0);
  const wVI = W - wV;

  const td: CSSProperties = { border: B, padding: '0 2px', verticalAlign: 'middle', whiteSpace: 'nowrap', overflow: 'hidden' };

  return (
    <div id="rf-print-area" className="rf-pagina" style={{ width: 816, height: 1560, background: '#fff', overflow: 'hidden' }}>
      <div style={{ width: W, transform: `scale(${K})`, transformOrigin: 'top left', background: '#fff' }}>
        <div style={{ fontFamily: 'Arial, sans-serif', color: '#000' }}>

          {/* ── Encabezado: título + I. Año Escolar / Tipo de Evaluación / Mes y Año ── */}
          <div style={{ display: 'flex', height: 72 }}>
            <div style={{ width: g.id[0] + g.id[1] + g.id[2] + g.id[3] }} />
            <div style={{ flex: 1, border: B }}>
              <div style={{ ...f9b, textAlign: 'center' }}>RESUMEN FINAL DEL RENDIMIENTO ESTUDIANTIL</div>
              <div style={{ ...f9b, textAlign: 'center' }}>Código del Formato: EMG</div>
              <div style={{ ...f9, display: 'flex', padding: '0 4px' }}>
                <span style={{ fontWeight: 700 }}>I. Año Escolar:&nbsp;</span>
                <span style={{ borderBottom: B, flex: 1, paddingLeft: 4 }}>{datos.ano}</span>
              </div>
              <div style={{ ...f9, display: 'flex', padding: '0 4px', alignItems: 'center' }}>
                <span style={{ fontWeight: 700 }}>Tipo de Evaluación:&nbsp;</span>
                <span style={{ borderBottom: B, width: 150, paddingLeft: 4 }}>{datos.tipo}</span>
                <span style={{ fontWeight: 700, marginLeft: 'auto' }}>Mes y Año:&nbsp;</span>
                <span style={{ borderBottom: B, width: 150, paddingLeft: 4 }}>{datos.mes}</span>
              </div>
            </div>
          </div>

          {/* ── II. Datos de la Institución Educativa ── */}
          <div style={{ ...f9b, height: 18 }}>II. Datos de la Institución Educativa:</div>
          <div style={{ ...f9, display: 'flex', height: 18 }}>
            <span style={{ width: 260 }}>Código de la institución Educativa:</span>
            <span style={{ width: 180 }}>{datos.institucion.codigo}</span>
            <span style={{ width: 190 }}>Denominación y Epónimo:</span>
            <span style={{ flex: 1 }}>{datos.institucion.denominacion}</span>
          </div>
          <div style={{ ...f9, display: 'flex', height: 18 }}>
            <span style={{ width: 80 }}>Dirección:</span>
            <span style={{ flex: 1 }}>{datos.institucion.direccion}</span>
            <span style={{ width: 70 }}>Teléfono:</span>
            <span style={{ width: 160 }}>{datos.institucion.telefono}</span>
          </div>
          <div style={{ ...f9, display: 'flex', height: 18 }}>
            <span style={{ width: 80 }}>Municipio:</span>
            <span style={{ width: 170 }}>{datos.institucion.municipio}</span>
            <span style={{ width: 110 }}>Entidad Federal:</span>
            <span style={{ width: 120 }}>{datos.institucion.entidadFederal}</span>
            <span style={{ width: 60 }}>CDCEE:</span>
            <span style={{ flex: 1 }}>{datos.institucion.entidadFederal}</span>
          </div>
          <div style={{ ...f9, display: 'flex', height: 18 }}>
            <span style={{ width: 90 }}>Director(a):</span>
            <span style={{ flex: 1 }}>{datos.institucion.director}</span>
            <span style={{ width: 130 }}>Cédula de Identidad:</span>
            <span style={{ width: 160 }}>{datos.institucion.cedulaDirector}</span>
          </div>

          <div style={{ height: 7 }} />

          {/* ── III + IV ── */}
          <div style={{ display: 'flex', height: 18 }}>
            <div style={{ ...f9b, width: W - g.areas.reduce((a, b) => a + b, 0) - g.grupo }}>III. Identificación del Estudiante:</div>
            <div style={{ ...f9b, flex: 1 }}>IV. Resumen Final del Rendimiento:</div>
          </div>

          {/* ── Tabla: encabezado + 35 alumnos + pie de totales ── */}
          <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: W }} className="rf-tabla">
            <colgroup>
              {g.id.map((w, i) => <col key={`i${i}`} style={{ width: w }} />)}
              {g.areas.map((w, i) => <col key={`a${i}`} style={{ width: w }} />)}
              <col style={{ width: g.grupo }} />
            </colgroup>
            <tbody>
              {/* filas 12-16: encabezados */}
              <tr style={{ height: 18 }}>
                <td rowSpan={5} style={{ ...td, ...f10, textAlign: 'center' }}>N°</td>
                <td rowSpan={5} style={{ ...td, ...f10, textAlign: 'center' }}>Cédula de <br />Identidad</td>
                <td rowSpan={5} style={{ ...td, ...f10, textAlign: 'center' }}>Apellidos</td>
                <td rowSpan={5} style={{ ...td, ...f10, textAlign: 'center' }}>Nombres</td>
                <td rowSpan={5} style={{ ...td, ...f10, textAlign: 'center' }}>Lugar de Nacimiento</td>
                <td rowSpan={5} style={{ ...td, ...f10, textAlign: 'center' }}>EF</td>
                <td rowSpan={5} style={{ ...td, ...f10, textAlign: 'center' }}>SEXO</td>
                <td colSpan={3} rowSpan={3} style={{ ...td, ...f10, textAlign: 'center' }}>FECHA DE <br />NACIMIENTO</td>
                <td colSpan={areas.length - 1} rowSpan={2} style={{ ...td, ...f10, textAlign: 'center' }}>ÁREAS DE FORMACIÓN</td>
                <td colSpan={2} rowSpan={3} style={{ ...td, ...f9, textAlign: 'center', whiteSpace: 'normal' }}>PARTICIPACIÓN EN GRUPOS DE CREACIÓN, RECREACIÓN Y PRODUCCIÓN</td>
              </tr>
              <tr style={{ height: 18 }} />
              <tr style={{ height: 18 }}>
                <td colSpan={areas.length - 1} style={{ ...td, ...f10, textAlign: 'center' }}>ÁREA COMÚN</td>
              </tr>
              <tr style={{ height: 18 }}>
                <td rowSpan={2} style={{ ...td, ...f9, textAlign: 'center' }}>DIA</td>
                <td rowSpan={2} style={{ ...td, ...f9, textAlign: 'center' }}>MES</td>
                <td rowSpan={2} style={{ ...td, ...f9, textAlign: 'center' }}>AÑO</td>
                {areas.map((ar, i) => <td key={ar.codigo} style={{ ...td, ...f9, textAlign: 'center' }}>{i + 1}</td>)}
                <td rowSpan={2} style={{ ...td, ...f9, textAlign: 'center' }}>GRUPO</td>
              </tr>
              <tr style={{ height: 18 }}>
                {areas.map(ar => <td key={ar.codigo} style={{ ...td, ...f9, textAlign: 'center' }}>{ar.codigo}</td>)}
              </tr>

              {/* filas 17-51: los 35 alumnos (o asteriscos / en blanco) */}
              {slots.map((s, idx) => (
                <tr key={idx} style={{ height: 20 }}>
                  <td style={{ ...td, ...f8, textAlign: 'center' }}>{s.numero}</td>
                  {s.asteriscos ? (
                    <>
                      <td style={{ ...td, ...f8 }}>{'***'}</td>
                      <td style={{ ...td, ...f8 }}>{'* * *'}</td>
                      <td style={{ ...td, ...f8 }}>{'* * *'}</td>
                      <td style={{ ...td, ...f8 }}>{'* * *'}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{'* *'}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{'*'}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{'* *'}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{'* *'}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{'* *'}</td>
                      {areas.map(ar => <td key={ar.codigo} style={{ ...td, ...f8, textAlign: 'center' }}>{'*'}</td>)}
                      <td style={{ ...td, ...f8 }}>{'*'}</td>
                    </>
                  ) : s.fila ? (
                    <>
                      <td style={{ ...td, ...f8 }}>{s.fila.cedula}</td>
                      <td style={{ ...td, ...f8 }}>{s.fila.apellidos}</td>
                      <td style={{ ...td, ...f8 }}>{s.fila.nombres}</td>
                      <td style={{ ...td, ...f8 }}>{s.fila.lugar}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{s.fila.ef}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{s.fila.sexo}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{s.fila.dia}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{s.fila.mesNac}</td>
                      <td style={{ ...td, ...f8, textAlign: 'center' }}>{s.fila.anio}</td>
                      {areas.map(ar => <td key={ar.codigo} style={{ ...td, ...f8, textAlign: 'center' }}>{mostrarNota(s.fila!.notas[ar.codigo] ?? '')}</td>)}
                      <td style={{ ...td, ...f8 }}>{s.fila.grupo}</td>
                    </>
                  ) : (
                    <>
                      <td style={td} /><td style={td} /><td style={td} /><td style={td} /><td style={td} />
                      <td style={td} /><td style={td} /><td style={td} /><td style={td} /><td style={td} />
                      {areas.map(ar => <td key={ar.codigo} style={td} />)}
                      <td style={td} />
                    </>
                  )}
                </tr>
              ))}

              {/* filas 52-56: pie de totales por área */}
              {(['inscritos', 'inasistentes', 'aprobados', 'noAprobados', 'noCursantes'] as const).map((k, i) => (
                <tr key={k} style={{ height: 18 }}>
                  {i === 0 && <td rowSpan={5} colSpan={3} style={{ ...td, ...f9b, paddingLeft: 4 }}>Total de Áreas de Formación</td>}
                  <td colSpan={7} style={{ ...td, ...f9b, textAlign: 'center' }}>
                    {k === 'inscritos' ? 'Inscritos' : k === 'inasistentes' ? 'Inasistentes' : k === 'aprobados' ? 'Aprobados' : k === 'noAprobados' ? 'No Aprobados' : 'No Cursantes'}
                  </td>
                  {areas.map((ar, j) => <td key={ar.codigo} style={{ ...td, ...f9b, textAlign: 'center' }}>{pad2(stats[j][k])}</td>)}
                  <td style={{ ...td, ...f9b, textAlign: 'center' }}>{'*'}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* ── V. Profesores por Áreas + VI. Identificación del Curso ── */}
          <div style={{ display: 'flex' }}>
            <div style={{ width: wV }}>
              <table style={{ borderCollapse: 'collapse', tableLayout: 'fixed', width: '100%' }}>
                <colgroup>
                  <col style={{ width: 22 }} /><col style={{ width: 40 }} /><col style={{ width: 190 }} />
                  <col style={{ width: 205 }} /><col style={{ width: 120 }} /><col style={{ width: wV - 577 }} />
                </colgroup>
                <tbody>
                  <tr style={{ height: 18 }}>
                    <td colSpan={2} style={{ ...td, ...f9b, border: 'none' }}>V. Profesores por Áreas:</td>
                    <td style={{ ...td, ...f9, textAlign: 'center' }} rowSpan={2}>Apellidos y Nombres</td>
                    <td style={{ ...td, ...f9, textAlign: 'center' }} rowSpan={2}>Cédula de Identidad</td>
                    <td colSpan={2} style={{ ...td, ...f9, textAlign: 'center' }} rowSpan={2}>Firma:</td>
                  </tr>
                  <tr style={{ height: 18 }}>
                    <td style={{ ...td, ...f9, textAlign: 'center' }}>N°</td>
                    <td colSpan={1} style={{ ...td, ...f9, textAlign: 'center' }}>Áreas de Formación</td>
                  </tr>
                  {areas.map((ar, i) => {
                    const prof = datos.profesores[i];
                    const sinUso = stats[i].inscritos === 0 || !prof?.nombre;
                    return (
                      <tr key={ar.codigo} style={{ height: 20 }}>
                        <td style={{ ...td, ...f9, textAlign: 'center' }}>{i + 1}</td>
                        <td style={{ ...td, ...f8, textAlign: 'center' }}>{ar.etiquetaV || ar.codigo}</td>
                        <td style={{ ...td, ...f8, whiteSpace: 'normal' }}>{ar.nombre}</td>
                        <td style={{ ...td, ...f8, textAlign: sinUso ? 'right' : 'left', whiteSpace: 'nowrap' }}>{sinUso ? '*' : prof!.nombre}</td>
                        <td style={{ ...td, ...f8, textAlign: sinUso ? 'right' : 'left' }}>{sinUso ? '*' : prof!.cedula}</td>
                        <td style={{ ...td, ...f8, textAlign: sinUso ? 'right' : 'left' }}>{sinUso ? '*' : ''}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div style={{ width: wVI, display: 'flex', flexDirection: 'column' }}>
              <div style={{ ...f9b, height: 18, textAlign: 'center' }}>VI. Identificación del Curso:</div>
              <div style={{ ...f9, height: 18, borderBottom: 'none', padding: '0 4px' }}>PLAN DE ESTUDIO:</div>
              <div style={{ ...f9, height: 18, borderTop: 'none', textAlign: 'center' }}>{datos.curso.planEstudio}</div>
              <div style={{ ...f9, height: 18, padding: '0 4px' }}>CÓDIGO:</div>
              <div style={{ ...f9, height: 18, textAlign: 'center' }}>{datos.curso.codigo}</div>
              <div style={{ ...f9, height: 18, padding: '0 4px' }}>AÑO CURSADO</div>
              <div style={{ ...f9, height: 18, textAlign: 'center' }}>{datos.curso.anioCursado}</div>
              <div style={{ ...f9, height: 18, padding: '0 4px' }}>SECCIÓN</div>
              <div style={{ ...f9, height: 18, textAlign: 'center' }}>{datos.curso.seccion}</div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                <div style={{ display: 'flex', flex: 1 }}>
                  <div style={{ ...f9, flex: 1.2, border: B, textAlign: 'center', whiteSpace: 'normal' }}>N° DE ESTUDIANTES POR SECCIÓN</div>
                  <div style={{ ...f9, flex: 1, border: B, borderLeft: 'none', textAlign: 'center', whiteSpace: 'normal' }}>N° DE ESTUDIANTES EN ESTA PÁGINA</div>
                </div>
                <div style={{ display: 'flex', height: 20 }}>
                  <div style={{ ...f10, flex: 1.2, border: B, borderTop: 'none', textAlign: 'center' }}>{datos.nPorSeccion}</div>
                  <div style={{ ...f10, flex: 1, border: B, borderTop: 'none', borderLeft: 'none', textAlign: 'center' }}>{n}</div>
                </div>
              </div>
            </div>
          </div>

          {/* ── VII. Observaciones ── (caja A68:BN69 del formato: línea 1 junto a la
              etiqueta, línea 2 debajo desde el borde izquierdo; texto Arial 8 verbatim
              de las sábanas NL/NR; "*" = sin observación en la sábana, igual que el Excel) */}
          <div style={{ border: B }}>
            <div style={{ display: 'flex', height: 18 }}>
              <div style={{ ...f9b, width: 170 }}>VII. Observaciones:</div>
              <div style={{ ...f8, flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', paddingRight: 2 }}>
                {datos.observaciones?.linea1 ?? ''}
              </div>
            </div>
            <div style={{ ...f8, height: 18, paddingLeft: 2, whiteSpace: 'nowrap', overflow: 'hidden' }}>
              {datos.observaciones?.linea2 ?? ''}
            </div>
          </div>

          <div style={{ height: 18 }} />

          {/* ── VIII. Remisión + IX. Recepción ── (proporciones del formato: 26/30/23/21 %) */}
          <div style={{ display: 'flex' }}>
            <div style={{ width: '26%' }}>
              <div style={{ ...f9b, height: 24 }}>VIII. Fecha de Remisión:</div>
              <div style={{ ...f9, height: 24 }}>Director(a)</div>
              <div style={{ ...f9, height: 24 }}>Apellidos y Nombres:</div>
              <div style={{ ...f9, height: 24, textAlign: 'center' }}>{datos.institucion.director}</div>
              <div style={{ ...f9, height: 24 }}>Cédula de Identidad:</div>
              <div style={{ ...f9, height: 24, textAlign: 'center' }}>{datos.institucion.cedulaDirector}</div>
              <div style={{ ...f9, height: 48 }}>Firma:</div>
            </div>
            <div style={{ width: '30%', border: B, height: 192, display: 'flex', alignItems: 'flex-start', justifyContent: 'center' }}>
              <div style={{ ...f9, paddingTop: 2 }}>SELLO DEL PLANTEL</div>
            </div>
            <div style={{ width: '23%' }}>
              <div style={{ ...f9b, height: 24 }}>IX. Fecha de Recepción:</div>
              <div style={{ ...f9, height: 24 }}>Funcionario Receptor</div>
              <div style={{ ...f9, height: 24 }}>Apellidos y Nombres:</div>
              <div style={{ ...f9, height: 24 }} />
              <div style={{ ...f9, height: 24 }}>Cédula de Identidad.:</div>
              <div style={{ ...f9, height: 24 }} />
              <div style={{ ...f9, height: 48 }}>Firma:</div>
            </div>
            <div style={{ flex: 1, border: B, height: 192, display: 'flex', alignItems: 'flex-start', justifyContent: 'center' }}>
              <div style={{ ...f9, paddingTop: 2 }}>SELLO DE LA ZONA EDUCATIVA</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
